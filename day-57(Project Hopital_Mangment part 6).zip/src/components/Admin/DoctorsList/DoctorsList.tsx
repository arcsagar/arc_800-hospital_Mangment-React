const DoctorList = () => {
    return (
        <div>
            DoctorList
        </div>
    )
};

export default DoctorList;