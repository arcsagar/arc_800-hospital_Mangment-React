const PatientList = () => {
    return (
        <div>
            patientList
        </div>
    )
};

export default  PatientList;