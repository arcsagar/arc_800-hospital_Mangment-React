const MyAppointment = () => {
    return (
        <div>
            MyAppointment
        </div>
    )
};

export default MyAppointment;