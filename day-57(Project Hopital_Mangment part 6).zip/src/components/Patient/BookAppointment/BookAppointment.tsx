const BookAppointment = () => {
    return (
        <div>
            BookAppointment
        </div>
    )
};

export default BookAppointment;