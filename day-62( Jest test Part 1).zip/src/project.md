project 
Health APP
Front End - JavaScript, HTML , CSS, React , API, FullCalendar, Redux;

-React Js 

BacKend - Node JS
Testing - 

1) UNIT TEST : Testing a perticular component / unit of complete application ( Jest, Testing library - React testing library )

2) END to End Testing  - Selenium (java platform - Testing of complete application flow) / Cypress.io (javaScript)


what is testing
* error niklana
* application ka flow
* quality - for health aata and for taste maid 1) health 2) content 3) protien 4) fat 5) calrois 
* test of food - masala, oil ,fat, tikha,  sweet,  = content of 

project =  user defines everything 
