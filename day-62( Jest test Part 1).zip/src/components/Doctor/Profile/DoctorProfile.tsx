const DoctorProfile = () => {
    return (
        <div>
            DoctorProfile
        </div>
    )
};

export default DoctorProfile;